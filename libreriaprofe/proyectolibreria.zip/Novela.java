/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectolibreria;

/**
 *
 * @author Angela
 */
public class Novela extends Libro{
    private String premioNobel;
    private String anoPremio;

    public String getPremioNobel() {
        return premioNobel;
    }

    public void setPremioNobel(String premioNobel) {
        this.premioNobel = premioNobel;
    }

    public String getAnoPremio() {
        return anoPremio;
    }

    public void setAnoPremio(String anoPremio) {
        this.anoPremio = anoPremio;
    }
    
    
    
    
    
}
